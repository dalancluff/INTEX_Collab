// ------------------- MODULES -------------------
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const pgSession = require('connect-pg-simple')(session);
const bcrypt = require('bcrypt');
const { Pool } = require('pg');
const path = require('path');

// ------------------- APP SETUP -------------------
const app = express();

// Serve static files (CSS, JS, images)
app.use(express.static(path.join(__dirname, 'public')));

// Session middleware
app.use(session({
  secret: process.env.SESSION_SECRET || 'intex',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// Middleware to parse POST form data
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set EJS as templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// PostgreSQL connection
const pool = new Pool({
  host: process.env.DB_HOST,      // Mapped to RDS_HOSTNAME in AWS Console
  port: process.env.DB_PORT,      // 5432
  user: process.env.DB_USER,      // Mapped to RDS_USERNAME
  password: process.env.DB_PASSWORD, // Mapped to RDS_PASSWORD
  database: process.env.DB_NAME,  // Set to 'postgres' (or 'ebdb')
  // The new part 
  ssl: { require: true, rejectUnauthorized: false }

});

// ------------------- SESSION SETUP -------------------
app.use(
  session({
    store: new pgSession({
      pool, // Use your PostgreSQL connection
      tableName: 'session',
      createTableIfMissing: true,
    }),
    secret: process.env.SESSION_SECRET || 'intex',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // false for localhost
      httpOnly: false, // allow cookies in browser during dev
      sameSite: 'lax',
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    },
  })
);

// ------------------- MIDDLEWARE -------------------
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Set EJS view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Debugging middleware to track session
app.use((req, res, next) => {
  console.log(
    'Session check:',
    req.session.user
      ? `✅ logged in as ${req.session.user.username}`
      : '❌ not logged in'
  );
  next();
});

// ------------------- AUTH MIDDLEWARE -------------------
function requireLogin(req, res, next) {
  if (req.session.user) next();
  else res.redirect('/login');
}

function requireManager(req, res, next) {
  if (req.session.user && req.session.user.role === 'manager') next();
  else res.status(403).send('Unauthorized: Manager only');
}

// ------------------- PUBLIC ROUTES -------------------
app.get('/', (req, res) => {
  res.render('index', { user: req.session.user || null });
});

// ------------------- LOGIN ROUTES -------------------
app.get('/login', (req, res) => {
  if (req.session.user) return res.redirect('/dashboard');
  res.render('login', { error_message: null, success_message: null });
});

app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Query user from the database
    const result = await pool.query(
      'SELECT user_id, username, password, role, first_name, last_name, is_active FROM users WHERE username = $1',
      [username]
    );

    if (result.rows.length === 0) {
      return res.render('login', {
        error_message: 'Invalid username or password',
        success_message: null,
      });
    }

    const user = result.rows[0];

    if (!user.is_active) {
      return res.render('login', {
        error_message: 'Your account has been deactivated',
        success_message: null,
      });
    }

    // TEMPORARY bypass bcrypt for testing plain-text passwords
    const isValidPassword =
      user.password.startsWith('$2b$') // hashed check
        ? await bcrypt.compare(password, user.password)
        : password === user.password;

    if (!isValidPassword) {
      return res.render('login', {
        error_message: 'Invalid username or password',
        success_message: null,
      });
    }

    // Update last login time
    await pool.query('UPDATE users SET last_login = NOW() WHERE user_id = $1', [
      user.user_id,
    ]);

    // Store session data
    req.session.user = {
      id: user.user_id,
      username: user.username,
      role: user.role,
      first_name: user.first_name,
      last_name: user.last_name,
    };

    console.log('✅ Login successful:', username);
    req.session.save((err) => {
      if (err) console.error('❌ Session save error:', err);
      else console.log('💾 Session saved for:', username);
      res.redirect('/dashboard');
    });
  } catch (err) {
    console.error('❌ Login error:', err);
    res.render('login', {
      error_message: 'An error occurred. Please try again.',
      success_message: null,
    });
  }
});

// ------------------- LOGOUT -------------------
app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) console.error('Logout error:', err);
    res.redirect('/');
  });
});

// ------------------- DASHBOARD -------------------
app.get('/dashboard', requireLogin, (req, res) => {
  res.render('dashboard', { user: req.session.user });
});

// ------------------- USER MANAGEMENT (Manager only) -------------------
app.get('/manage-users', requireLogin, requireManager, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT user_id, username, email, role, first_name, last_name, is_active FROM users ORDER BY username'
    );
    res.render('manage-users', { users: result.rows });
  } catch (err) {
    console.error(err);
    res.send('Error fetching users');
  }
});

app.get('/add-user', requireLogin, requireManager, (req, res) => {
  res.render('add-user');
});

app.post('/add-user', requireLogin, requireManager, async (req, res) => {
  const { username, email, password, role, first_name, last_name } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    await pool.query(
      `INSERT INTO users (username, email, password, role, first_name, last_name, is_active)
       VALUES ($1, $2, $3, $4, $5, $6, true)`,
      [username, email, hashedPassword, role, first_name, last_name]
    );
    res.redirect('/manage-users');
  } catch (err) {
    console.error(err);
    res.send('Error adding user: ' + err.message);
  }
});

app.get('/edit-user/:id', requireLogin, requireManager, async (req, res) => {
  const userId = req.params.id;
  try {
    const result = await pool.query(
      'SELECT user_id, username, email, role, first_name, last_name, is_active FROM users WHERE user_id = $1',
      [userId]
    );
    if (result.rows.length > 0) {
      res.render('edit-user', { user: result.rows[0] });
    } else {
      res.send('User not found');
    }
  } catch (err) {
    console.error(err);
    res.send('Error fetching user');
  }
});

app.post('/edit-user/:id', requireLogin, requireManager, async (req, res) => {
  const userId = req.params.id;
  const { username, email, password, role, first_name, last_name, is_active } =
    req.body;
  try {
    if (password && password.trim() !== '') {
      const hashedPassword = await bcrypt.hash(password, 10);
      await pool.query(
        'UPDATE users SET username=$1, email=$2, password=$3, role=$4, first_name=$5, last_name=$6, is_active=$7 WHERE user_id=$8',
        [
          username,
          email,
          hashedPassword,
          role,
          first_name,
          last_name,
          is_active === 'on',
          userId,
        ]
      );
    } else {
      await pool.query(
        'UPDATE users SET username=$1, email=$2, role=$3, first_name=$4, last_name=$5, is_active=$6 WHERE user_id=$7',
        [
          username,
          email,
          role,
          first_name,
          last_name,
          is_active === 'on',
          userId,
        ]
      );
    }
    res.redirect('/manage-users');
  } catch (err) {
    console.error(err);
    res.send('Error updating user: ' + err.message);
  }
});

app.post('/delete-user/:id', requireLogin, requireManager, async (req, res) => {
  const userId = req.params.id;
  try {
    await pool.query('DELETE FROM users WHERE user_id=$1', [userId]);
    res.redirect('/manage-users');
  } catch (err) {
    console.error(err);
    res.send('Error deleting user');
  }
});

// ------------------- PARTICIPANTS CRUD -------------------
app.get('/participants', requireLogin, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM participants ORDER BY participantlastname ASC'
    );
    res.render('participants', { participants: result.rows });
  } catch (err) {
    console.error('Error fetching participants:', err);
    res.status(500).send('Error loading participants page');
  }
});

app.get('/participants/add', requireLogin, (req, res) => {
  res.render('add-participant');
});

app.post('/participants/add', requireLogin, async (req, res) => {
  const { firstname, lastname, email } = req.body;
  try {
    await pool.query(
      'INSERT INTO participants (participantfirstname, participantlastname, email) VALUES ($1, $2, $3)',
      [firstname, lastname, email]
    );
    res.redirect('/participants');
  } catch (err) {
    console.error('Error adding participant:', err);
    res.send('Error adding participant');
  }
});

app.get('/participants/edit/:id', requireLogin, async (req, res) => {
  const id = req.params.id;
  try {
    const result = await pool.query(
      'SELECT * FROM participants WHERE participantid = $1',
      [id]
    );
    if (result.rows.length > 0)
      res.render('edit-participant', { participant: result.rows[0] });
    else res.send('Participant not found');
  } catch (err) {
    console.error(err);
    res.send('Error loading participant');
  }
});

app.post('/participants/edit/:id', requireLogin, async (req, res) => {
  const id = req.params.id;
  const { firstname, lastname, email } = req.body;
  try {
    await pool.query(
      'UPDATE participants SET participantfirstname=$1, participantlastname=$2, email=$3 WHERE participantid=$4',
      [firstname, lastname, email, id]
    );
    res.redirect('/participants');
  } catch (err) {
    console.error(err);
    res.send('Error updating participant');
  }
});

app.post('/participants/delete/:id', requireLogin, async (req, res) => {
  const id = req.params.id;
  try {
    await pool.query('DELETE FROM participants WHERE participantid=$1', [id]);
    res.redirect('/participants');
  } catch (err) {
    console.error(err);
    res.send('Error deleting participant');
  }
});

// ------------------- PARTICIPANTS PAGE -------------------
// This route pulls data from your local Postgres table for now.
// When AWS is live, the same query will automatically work once
// your .env points to the AWS RDS connection info.
app.get('/participants', requireLogin, async (req, res) => {
  try {
    // =========================================================
    // POSTGRES QUERY (works for both local & AWS)
    // =========================================================
    const result = await pool.query(
      'SELECT participantid, participantfirstname, participantlastname, email FROM participants ORDER BY participantlastname ASC'
    );

    // Store query results
    const participants = result.rows;

    // Render EJS template with the data
    res.render('participants', { participants });

  } catch (err) {
    // =========================================================
    // If this fails, likely means:
    // 1. The "participants" table doesn't exist in your DB, or
    // 2. Your DB connection info is incorrect in .env.
    // =========================================================
    console.error('❌ Error loading participants page:', err);
    res.status(500).send('Error loading participants page');
  }
});



// ------------------- ERROR HANDLING -------------------
app.use((req, res) => res.status(404).send('Page not found'));
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

// ------------------- START SERVER -------------------
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`🚀 Server running on http://localhost:${port}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
});